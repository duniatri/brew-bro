import { formatTime, parseTimeToSeconds, formatDate } from '../../src/utils/imageUtils';

describe('imageUtils', () => {
  describe('formatTime', () => {
    it('formats seconds correctly', () => {
      expect(formatTime(0)).toBe('0:00');
      expect(formatTime(30)).toBe('0:30');
      expect(formatTime(60)).toBe('1:00');
      expect(formatTime(90)).toBe('1:30');
      expect(formatTime(120)).toBe('2:00');
      expect(formatTime(185)).toBe('3:05');
    });

    it('handles negative values', () => {
      expect(formatTime(-10)).toBe('0:00');
    });

    it('handles undefined/null safely', () => {
      expect(formatTime(undefined as any)).toBe('0:00');
      expect(formatTime(null as any)).toBe('0:00');
    });
  });

  describe('parseTimeToSeconds', () => {
    it('parses mm:ss format correctly', () => {
      expect(parseTimeToSeconds('1:30')).toBe(90);
      expect(parseTimeToSeconds('2:00')).toBe(120);
      expect(parseTimeToSeconds('0:45')).toBe(45);
    });

    it('parses plain seconds', () => {
      expect(parseTimeToSeconds('90')).toBe(90);
    });

    it('handles invalid input', () => {
      expect(parseTimeToSeconds('')).toBe(0);
      expect(parseTimeToSeconds('abc')).toBe(0);
      expect(parseTimeToSeconds(undefined as any)).toBe(0);
    });
  });

  describe('formatDate', () => {
    it('formats ISO date string', () => {
      const result = formatDate('2024-01-15T10:30:00Z');
      // Just check it returns a non-empty string (locale dependent)
      expect(result.length).toBeGreaterThan(0);
      expect(result).not.toBe('Unknown date');
    });

    it('handles invalid date', () => {
      expect(formatDate('')).toBe('Unknown date');
      expect(formatDate('invalid')).toBe('Unknown date');
    });

    it('handles undefined safely', () => {
      expect(formatDate(undefined as any)).toBe('Unknown date');
    });
  });
});
