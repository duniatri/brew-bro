import { apiService } from '../../src/services/api';

// Mock fetch
global.fetch = jest.fn();

describe('ApiService', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('analyzeRoast', () => {
    it('returns success response when API returns valid data', async () => {
      const mockResponse = {
        success: true,
        roastLevel: 'medium',
        temperature: { celsius: '85-90', fahrenheit: '185-194' },
        description: 'A well-balanced medium roast',
      };

      (global.fetch as jest.Mock).mockResolvedValueOnce({
        ok: true,
        json: async () => mockResponse,
      });

      const result = await apiService.analyzeRoast('base64imagestring');

      expect(result.success).toBe(true);
      if (result.success) {
        expect(result.roastLevel).toBe('medium');
        expect(result.temperature.celsius).toBe('85-90');
        expect(result.temperature.fahrenheit).toBe('185-194');
        expect(result.description).toBe('A well-balanced medium roast');
      }
    });

    it('returns error response when API returns success: false', async () => {
      const mockResponse = {
        success: false,
        error: 'Could not analyze image',
      };

      (global.fetch as jest.Mock).mockResolvedValueOnce({
        ok: true,
        json: async () => mockResponse,
      });

      const result = await apiService.analyzeRoast('base64imagestring');

      expect(result.success).toBe(false);
      if (!result.success) {
        expect(result.error).toBe('Could not analyze image');
      }
    });

    it('handles server errors gracefully', async () => {
      (global.fetch as jest.Mock).mockResolvedValueOnce({
        ok: false,
        status: 500,
        text: async () => 'Internal Server Error',
      });

      const result = await apiService.analyzeRoast('base64imagestring');

      expect(result.success).toBe(false);
      if (!result.success) {
        expect(result.error).toContain('Server error');
      }
    });

    it('handles network errors gracefully', async () => {
      (global.fetch as jest.Mock).mockRejectedValueOnce(new Error('Network error'));

      const result = await apiService.analyzeRoast('base64imagestring');

      expect(result.success).toBe(false);
      if (!result.success) {
        expect(result.error).toContain('Network error');
      }
    });

    it('provides default values for missing response fields', async () => {
      const mockResponse = {
        success: true,
        // Missing roastLevel, temperature, description
      };

      (global.fetch as jest.Mock).mockResolvedValueOnce({
        ok: true,
        json: async () => mockResponse,
      });

      const result = await apiService.analyzeRoast('base64imagestring');

      expect(result.success).toBe(true);
      if (result.success) {
        expect(result.roastLevel).toBe('unknown');
        expect(result.temperature.celsius).toBe('N/A');
        expect(result.temperature.fahrenheit).toBe('N/A');
        expect(result.description).toBe('No description available.');
      }
    });

    it('sends correct request body', async () => {
      const mockResponse = {
        success: true,
        roastLevel: 'light',
        temperature: { celsius: '90-96', fahrenheit: '194-205' },
        description: 'Light roast',
      };

      (global.fetch as jest.Mock).mockResolvedValueOnce({
        ok: true,
        json: async () => mockResponse,
      });

      await apiService.analyzeRoast('testbase64');

      expect(global.fetch).toHaveBeenCalledWith(
        expect.stringContaining('/api/analyze-roast'),
        expect.objectContaining({
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ image: 'testbase64' }),
        })
      );
    });
  });
});
