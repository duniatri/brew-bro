import React from 'react';
import { render, fireEvent } from '@testing-library/react-native';
import { NavigationContainer } from '@react-navigation/native';
import { PaperProvider } from 'react-native-paper';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { HomeScreen } from '../../src/screens/HomeScreen';
import { theme } from '../../src/theme';

// Mock navigation
const mockNavigate = jest.fn();
jest.mock('@react-navigation/native', () => {
  const actualNav = jest.requireActual('@react-navigation/native');
  return {
    ...actualNav,
    useNavigation: () => ({
      navigate: mockNavigate,
    }),
  };
});

// Mock expo vector icons
jest.mock('@expo/vector-icons', () => {
  const { View } = require('react-native');
  return {
    Ionicons: View,
  };
});

const renderWithProviders = (component: React.ReactElement) => {
  return render(
    <SafeAreaProvider
      initialMetrics={{
        frame: { x: 0, y: 0, width: 0, height: 0 },
        insets: { top: 0, left: 0, right: 0, bottom: 0 },
      }}
    >
      <PaperProvider theme={theme}>
        <NavigationContainer>
          {component}
        </NavigationContainer>
      </PaperProvider>
    </SafeAreaProvider>
  );
};

describe('HomeScreen', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('renders without crashing', () => {
    const { getByText } = renderWithProviders(<HomeScreen />);
    expect(getByText('Brew Bro')).toBeTruthy();
  });

  it('displays the app subtitle', () => {
    const { getByText } = renderWithProviders(<HomeScreen />);
    expect(getByText('Your Coffee Roast Analyzer')).toBeTruthy();
  });

  it('displays analyze coffee beans button', () => {
    const { getByText } = renderWithProviders(<HomeScreen />);
    expect(getByText('Analyze Coffee Beans')).toBeTruthy();
  });

  it('displays start timer button', () => {
    const { getByText } = renderWithProviders(<HomeScreen />);
    expect(getByText('Start Timer')).toBeTruthy();
  });

  it('displays view history button', () => {
    const { getByText } = renderWithProviders(<HomeScreen />);
    expect(getByText('View History')).toBeTruthy();
  });

  it('navigates to CameraAnalysis when analyze button is pressed', () => {
    const { getByLabelText } = renderWithProviders(<HomeScreen />);
    const analyzeButton = getByLabelText('Analyze coffee beans');
    fireEvent.press(analyzeButton);
    expect(mockNavigate).toHaveBeenCalledWith('CameraAnalysis');
  });

  it('navigates to Timer when start timer button is pressed', () => {
    const { getByLabelText } = renderWithProviders(<HomeScreen />);
    const timerButton = getByLabelText('Start brewing timer');
    fireEvent.press(timerButton);
    expect(mockNavigate).toHaveBeenCalledWith('Timer', undefined);
  });

  it('navigates to History when view history button is pressed', () => {
    const { getByLabelText } = renderWithProviders(<HomeScreen />);
    const historyButton = getByLabelText('View brew history');
    fireEvent.press(historyButton);
    expect(mockNavigate).toHaveBeenCalledWith('History');
  });
});
