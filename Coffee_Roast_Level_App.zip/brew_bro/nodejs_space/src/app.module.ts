import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { RoastAnalyzerModule } from './roast-analyzer/roast-analyzer.module';

@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    RoastAnalyzerModule,
  ],
})
export class AppModule {}
