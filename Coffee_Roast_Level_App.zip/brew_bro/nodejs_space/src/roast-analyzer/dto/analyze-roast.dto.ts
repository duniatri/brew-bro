import { ApiProperty } from '@nestjs/swagger';
import { IsString, IsNotEmpty } from 'class-validator';

export class AnalyzeRoastDto {
  @ApiProperty({
    description: 'Base64 encoded image of coffee beans',
    example: 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==',
  })
  @IsString()
  @IsNotEmpty()
  image: string;
}

export class TemperatureDto {
  @ApiProperty({ example: '85-90' })
  celsius: string;

  @ApiProperty({ example: '185-194' })
  fahrenheit: string;
}

export class AnalyzeRoastSuccessResponseDto {
  @ApiProperty({ example: true })
  success: true;

  @ApiProperty({
    description: 'Detected roast level',
    enum: ['light', 'light-medium', 'medium', 'medium-dark', 'dark'],
    example: 'medium',
  })
  roastLevel: string;

  @ApiProperty({ type: TemperatureDto })
  temperature: TemperatureDto;

  @ApiProperty({
    description: 'AI-generated analysis description',
    example: 'The coffee beans show a uniform medium brown color with a slight oil sheen...',
  })
  description: string;
}

export class AnalyzeRoastErrorResponseDto {
  @ApiProperty({ example: false })
  success: false;

  @ApiProperty({ example: 'Failed to analyze image' })
  error: string;
}
