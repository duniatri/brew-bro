import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import axios from 'axios';

type RoastLevel = 'light' | 'light-medium' | 'medium' | 'medium-dark' | 'dark';

interface TemperatureRange {
  celsius: string;
  fahrenheit: string;
}

interface AnalysisResult {
  success: true;
  roastLevel: RoastLevel;
  temperature: TemperatureRange;
  description: string;
}

interface AnalysisError {
  success: false;
  error: string;
}

const TEMPERATURE_MAP: Record<RoastLevel, TemperatureRange> = {
  light: { celsius: '90-96', fahrenheit: '194-205' },
  'light-medium': { celsius: '88-93', fahrenheit: '190-199' },
  medium: { celsius: '85-90', fahrenheit: '185-194' },
  'medium-dark': { celsius: '82-88', fahrenheit: '180-190' },
  dark: { celsius: '80-85', fahrenheit: '176-185' },
};

const VALID_ROAST_LEVELS: RoastLevel[] = ['light', 'light-medium', 'medium', 'medium-dark', 'dark'];

@Injectable()
export class RoastAnalyzerService {
  private readonly logger = new Logger(RoastAnalyzerService.name);
  private readonly apiKey: string;
  private readonly apiEndpoint = 'https://routellm.abacus.ai/v1/chat/completions';

  constructor(private configService: ConfigService) {
    this.apiKey = this.configService.get<string>('ABACUSAI_API_KEY') || '';
  }

  async analyzeRoast(base64Image: string): Promise<AnalysisResult | AnalysisError> {
    try {
      if (!this.apiKey) {
        this.logger.error('ABACUSAI_API_KEY not configured');
        return { success: false, error: 'API key not configured' };
      }

      const imageUrl = base64Image.startsWith('data:')
        ? base64Image
        : `data:image/jpeg;base64,${base64Image}`;

      const prompt = `Analyze this image of coffee beans and determine the roast level.

You must respond with valid JSON containing:
- "roastLevel": one of exactly these values: "light", "light-medium", "medium", "medium-dark", "dark"
- "description": a brief 1-2 sentence description of your analysis

Example response:
{"roastLevel": "medium", "description": "The beans show a uniform medium brown color with minimal surface oil."}

Respond ONLY with the JSON object, no other text.`;

      this.logger.log('Calling RouteLLM API for roast analysis');

      const response = await axios.post(
        this.apiEndpoint,
        {
          model: 'gpt-4o',
          messages: [
            {
              role: 'user',
              content: [
                { type: 'text', text: prompt },
                { type: 'image_url', image_url: { url: imageUrl } },
              ],
            },
          ],
          max_tokens: 500,
          response_format: { type: 'json_object' },
        },
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${this.apiKey}`,
          },
          timeout: 60000,
        },
      );

      const content = response.data?.choices?.[0]?.message?.content;
      if (!content) {
        this.logger.error('Empty response from LLM');
        return { success: false, error: 'Empty response from AI model' };
      }

      this.logger.log(`LLM response: ${content}`);

      let parsed: { roastLevel?: string; description?: string };
      try {
        parsed = JSON.parse(content);
      } catch {
        this.logger.error(`Failed to parse LLM response: ${content}`);
        return { success: false, error: 'Failed to parse AI response' };
      }

      const roastLevel = parsed.roastLevel?.toLowerCase() as RoastLevel;
      if (!VALID_ROAST_LEVELS.includes(roastLevel)) {
        this.logger.error(`Invalid roast level: ${parsed.roastLevel}`);
        return { success: false, error: `Invalid roast level detected: ${parsed.roastLevel}` };
      }

      const temperature = TEMPERATURE_MAP[roastLevel];
      const description = parsed.description || 'No description provided';

      return {
        success: true,
        roastLevel,
        temperature,
        description,
      };
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unknown error';
      this.logger.error(`Roast analysis failed: ${message}`);
      return { success: false, error: `Analysis failed: ${message}` };
    }
  }
}
