import { Controller, Post, Body, HttpCode, HttpStatus } from '@nestjs/common';
import { ApiTags, ApiOperation, ApiResponse, ApiBody } from '@nestjs/swagger';
import { RoastAnalyzerService } from './roast-analyzer.service';
import {
  AnalyzeRoastDto,
  AnalyzeRoastSuccessResponseDto,
  AnalyzeRoastErrorResponseDto,
} from './dto/analyze-roast.dto';

@ApiTags('Roast Analysis')
@Controller('api')
export class RoastAnalyzerController {
  constructor(private readonly roastAnalyzerService: RoastAnalyzerService) {}

  @Post('analyze-roast')
  @HttpCode(HttpStatus.OK)
  @ApiOperation({
    summary: 'Analyze coffee bean roast level',
    description:
      'Upload a base64-encoded image of coffee beans to determine the roast level and get recommended Aeropress water temperature.',
  })
  @ApiBody({ type: AnalyzeRoastDto })
  @ApiResponse({
    status: 200,
    description: 'Successful analysis',
    type: AnalyzeRoastSuccessResponseDto,
  })
  @ApiResponse({
    status: 200,
    description: 'Analysis error',
    type: AnalyzeRoastErrorResponseDto,
  })
  async analyzeRoast(
    @Body() dto: AnalyzeRoastDto,
  ): Promise<AnalyzeRoastSuccessResponseDto | AnalyzeRoastErrorResponseDto> {
    return this.roastAnalyzerService.analyzeRoast(dto.image) as Promise<
      AnalyzeRoastSuccessResponseDto | AnalyzeRoastErrorResponseDto
    >;
  }
}
