import { Module } from '@nestjs/common';
import { RoastAnalyzerController } from './roast-analyzer.controller';
import { RoastAnalyzerService } from './roast-analyzer.service';

@Module({
  controllers: [RoastAnalyzerController],
  providers: [RoastAnalyzerService],
})
export class RoastAnalyzerModule {}
